#!/usr/bin/env python3
"""
Job Market Analyzer (Resume Project)
- Scrapes job listings (example: RemoteOK) using requests + BeautifulSoup
- Extracts skills via a simple keyword dictionary (skills.yml)
- Saves to CSV
- Produces basic charts (Matplotlib)

USAGE
-----
pip install -r requirements.txt
python job_market_analyzer.py scrape --query "data scientist" --pages 2 --out jobs.csv
python job_market_analyzer.py enrich --in jobs.csv --skills skills.yml --out jobs_enriched.csv
python job_market_analyzer.py analyze --in jobs_enriched.csv --topk 20 --outdir charts/

DISCLAIMER
----------
Always check and respect a site's robots.txt and Terms of Service.
Use small page counts and polite delays. This code is for educational use.
"""

import argparse, time, random, re, sys, csv, os, io, yaml, json
from pathlib import Path
from typing import List, Dict
import requests
from bs4 import BeautifulSoup
import pandas as pd
import matplotlib.pyplot as plt

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; JobMarketAnalyzer/1.0; +https://example.com)"
}

def polite_delay(min_s=1.0, max_s=2.0):
    time.sleep(random.uniform(min_s, max_s))

def is_scraping_allowed(base_url: str, path: str) -> bool:
    # Simple robots.txt check
    try:
        r = requests.get(base_url.rstrip("/") + "/robots.txt", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return True  # If robots not found, we assume allowed but still be polite
        disallows = []
        for line in r.text.splitlines():
            line = line.strip().lower()
            if line.startswith("disallow:"):
                disallows.append(line.replace("disallow:", "").strip())
        for rule in disallows:
            if path.startswith(rule):
                return False
        return True
    except Exception:
        return True

# ------------------
# Scraper: RemoteOK
# ------------------
def fetch_remoteok(query: str, pages: int = 1) -> List[Dict]:
    """
    Fetch jobs from RemoteOK by parsing HTML.
    NOTE: RemoteOK layout may change; adjust selectors accordingly.
    """
    base_url = "https://remoteok.com"
    path = "/"
    if not is_scraping_allowed(base_url, path):
        print("Scraping not allowed by robots.txt for RemoteOK. Exiting.", file=sys.stderr)
        return []

    all_jobs = []
    for page in range(1, pages + 1):
        url = f"{base_url}/remote-{query.replace(' ', '-')}-jobs?page={page}"
        print(f"Fetching: {url}")
        resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=20)
        if resp.status_code != 200:
            print(f"Failed: HTTP {resp.status_code}", file=sys.stderr)
            break
        soup = BeautifulSoup(resp.text, "html.parser")

        # Job rows usually have class 'job' in <tr> but structure can vary.
        rows = soup.select("tr.job")
        for row in rows:
            title_el = row.select_one("td.company_and_position h2")
            company_el = row.select_one("td.company_and_position h3")
            location_el = row.select_one("div.location")
            date_el = row.select_one("time")
            link_el = row.select_one("a.preventLink")

            title = title_el.get_text(strip=True) if title_el else None
            company = company_el.get_text(strip=True) if company_el else None
            location = location_el.get_text(strip=True) if location_el else "Remote"
            date = date_el.get("datetime") if date_el else None
            link = base_url + link_el.get("href") if link_el and link_el.get("href") else url

            # Description teaser (if available)
            tags = [t.get_text(strip=True) for t in row.select("a.tag")]
            desc_el = row.select_one("td.description")
            description = desc_el.get_text(" ", strip=True) if desc_el else " ".join(tags)

            all_jobs.append({
                "title": title,
                "company": company,
                "location": location,
                "posted": date,
                "url": link,
                "source": "RemoteOK",
                "description": description
            })
        polite_delay(1.0, 2.0)

    return all_jobs

def save_jobs_csv(jobs: List[Dict], out_path: Path):
    df = pd.DataFrame(jobs)
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df)} jobs -> {out_path}")

# ------------------
# Skill Extraction
# ------------------
def load_skills_map(skills_file: Path) -> Dict[str, List[str]]:
    with open(skills_file, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    # Flatten categories into {Canonical: [keywords...]}
    canon_to_keywords = {}
    for _cat, mapping in raw.items():
        for canonical, keywords in mapping.items():
            canon_to_keywords[canonical] = keywords
    return canon_to_keywords

def extract_skills(text: str, skills_map: Dict[str, List[str]]) -> List[str]:
    text_low = text.lower()
    found = []
    for canonical, kws in skills_map.items():
        for kw in kws:
            pattern = r"\b" + re.escape(kw.lower()) + r"\b"
            if re.search(pattern, text_low):
                found.append(canonical)
                break
    return sorted(set(found))

def enrich_with_skills(in_csv: Path, skills_file: Path, out_csv: Path):
    skills_map = load_skills_map(skills_file)
    df = pd.read_csv(in_csv)
    df["skills"] = df["description"].fillna("").apply(lambda t: ", ".join(extract_skills(t, skills_map)))
    df.to_csv(out_csv, index=False)
    print(f"Enriched -> {out_csv}")

# ------------------
# Analysis & Charts
# ------------------
def analyze_and_plot(in_csv: Path, outdir: Path, topk: int = 20):
    outdir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(in_csv)
    # Explode skills to count
    skills_series = (
        df["skills"].dropna().astype(str).str.split(", ").explode().str.strip()
    )
    skills_series = skills_series[skills_series != ""]

    top_counts = skills_series.value_counts().head(topk)
    # Bar chart: top skills
    plt.figure()
    top_counts.sort_values(ascending=True).plot(kind="barh")
    plt.xlabel("Count")
    plt.ylabel("Skill")
    plt.title(f"Top {topk} Skills in Job Postings")
    plt.tight_layout()
    bar_path = outdir / "top_skills.png"
    plt.savefig(bar_path)
    plt.close()

    # Location counts (if available)
    if "location" in df.columns:
        loc_counts = df["location"].fillna("Unknown").value_counts().head(15)
        plt.figure()
        loc_counts.sort_values(ascending=True).plot(kind="barh")
        plt.xlabel("Count")
        plt.ylabel("Location")
        plt.title("Top Locations")
        plt.tight_layout()
        loc_path = outdir / "top_locations.png"
        plt.savefig(loc_path)
        plt.close()

    # Jobs over time (if posted available)
    if "posted" in df.columns:
        try:
            ts = pd.to_datetime(df["posted"], errors="coerce").dropna().dt.date.value_counts().sort_index()
            if not ts.empty:
                plt.figure()
                ts.plot(kind="line")
                plt.xlabel("Date")
                plt.ylabel("Postings")
                plt.title("Postings Over Time")
                plt.tight_layout()
                time_path = outdir / "postings_over_time.png"
                plt.savefig(time_path)
                plt.close()
        except Exception:
            pass

    print(f"Charts saved in {outdir}")

# ------------------
# CLI
# ------------------
def main():
    parser = argparse.ArgumentParser(description="Job Market Analyzer")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("scrape", help="Scrape jobs (example: RemoteOK)")
    p1.add_argument("--query", required=True, help="e.g., data scientist")
    p1.add_argument("--pages", type=int, default=1)
    p1.add_argument("--out", required=True, help="Output CSV path")

    p2 = sub.add_parser("enrich", help="Extract skills into CSV")
    p2.add_argument("--in", dest="in_csv", required=True)
    p2.add_argument("--skills", required=True, help="skills.yml path")
    p2.add_argument("--out", required=True, help="Output CSV path")

    p3 = sub.add_parser("analyze", help="Make charts from enriched CSV")
    p3.add_argument("--in", dest="in_csv", required=True)
    p3.add_argument("--topk", type=int, default=20)
    p3.add_argument("--outdir", required=True)

    args = parser.parse_args()

    if args.cmd == "scrape":
        jobs = fetch_remoteok(args.query, pages=args.pages)
        save_jobs_csv(jobs, Path(args.out))

    elif args.cmd == "enrich":
        enrich_with_skills(Path(args.in_csv), Path(args.skills), Path(args.out))

    elif args.cmd == "analyze":
        analyze_and_plot(Path(args.in_csv), Path(args.outdir), topk=args.topk)

if __name__ == "__main__":
    main()
