# Job Market Analyzer (Python)

A resume-ready project that scrapes job postings, extracts skills, and visualizes in-demand skills.

## Features
- Requests + BeautifulSoup scraper (example: RemoteOK)
- Keyword-based skill extraction via `skills.yml`
- CSV outputs and Matplotlib charts
- Command-line interface

## Setup
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Usage
1. **Scrape jobs**
```bash
python job_market_analyzer.py scrape --query "data scientist" --pages 2 --out jobs.csv
```
> Always respect a site's robots.txt and Terms of Service. Keep page counts small and add delays.

2. **Extract skills**
```bash
python job_market_analyzer.py enrich --in jobs.csv --skills skills.yml --out jobs_enriched.csv
```

3. **Analyze & visualize**
```bash
python job_market_analyzer.py analyze --in jobs_enriched.csv --topk 20 --outdir charts/
```

The charts will be saved in `charts/` as PNG files.

## Resume bullets
- Built a Python pipeline (Requests, BeautifulSoup, Pandas, Matplotlib) to scrape and analyze job postings.
- Extracted skills using a custom dictionary; generated charts highlighting top skills and trends.
- Automated CLI flow to reproduce results and export CSVs and visuals.

